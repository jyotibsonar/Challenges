package com.testyantra.basePackage.DAO;

import java.util.List;

import com.testyantra.basePackage.DTO.Employee;

public interface DAOInterface {
	
	public Employee authenticate(int id, String password);
	
	public List<Employee> getEmployee();
	
	public int addEmployee(Employee emp);

}
