package com.testyantra.basePackage.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.testyantra.basePackage.DTO.Employee;
import com.testyantra.basePackage.Service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	EmpService service1;
	
	@GetMapping("/home")
	public String adding() {
		return "empreg";
	}
	
	@PostMapping(path="/reg")
	public String addEmployee(ModelMap map,Employee emp) throws Exception {
			service1.addEmployee(emp);
			String msg="Inserted Successfully";
			map.addAttribute("msg",msg);
			return "display";
}
	
	@GetMapping(path="/display")
	public String getAllDetails(ModelMap map) {
		List<Employee> l = service1.getEmployee();
		map.addAttribute("details",l);
		return "display";
}
	
	
	@GetMapping(path="/athuentication")
	public String authenticationpage() {
		return "athuentication";
	}
	
	@PostMapping(path="/athuentication")
	public String authentication(@RequestParam String name,@RequestParam String password,
								HttpServletRequest req,ModelMap map) {
		if(service1.authenticate(id,password) {
		HttpSession session = req.getSession();
		session.setAttribute("name", name);
		return "login";
		}else return"athuentication";
	}
	
	@GetMapping(path="/logout")
	public String logout(HttpServletRequest req) {
		HttpSession session= req.getSession(false);
		session.invalidate();
		return "athuentication";
	}
}
