package com.testyantra.basePackage.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.testyantra.basePackage.DAO.DAOImplemtation;
import com.testyantra.basePackage.DTO.Employee;

public class EmpService implements EmployeeServiceInterface{
	
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("/NewEmployee/src/main/webapp/WEB-INF/Config.xml");
	DAOImplemtation dao= context.getBean("myEmployeeDAO",DAOImplemtation.class);
	
	@Override
	public Employee authenticate(int id, String password) {
		
		Employee key= dao.authenticate(id, password);
		if(password.equals(key.getPassword())) {
			return key;
		}else return null;
	}
	

	public List<Employee> getEmployee() {
	
		return dao.getEmployee();
	}
	
	public int addEmployee(Employee emp) {
		
		return dao.addEmployee(emp);
	}
	
	

}
