package com.testyantra.basePackage.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.testyantra.basePackage.DTO.Employee;

public class RowMapperImplementation implements RowMapper<Employee> {

	
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		Employee emp = new Employee();
		emp.setId(rs.getInt(1));
		emp.setName(rs.getString(2));
		emp.setPassword(rs.getString(3));
		return emp;


	}

}
