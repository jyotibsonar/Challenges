package com.testyantra.basePackage.Service;

import java.util.List;

import com.testyantra.basePackage.DTO.Employee;

public interface EmployeeServiceInterface {
public Employee authenticate(int id, String password);
	
	public List<Employee> getEmployee();
	
	public int addEmployee(Employee emp);

}
