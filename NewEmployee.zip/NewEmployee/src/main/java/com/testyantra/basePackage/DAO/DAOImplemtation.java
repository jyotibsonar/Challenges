package com.testyantra.basePackage.DAO;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.mysql.cj.xdevapi.RowResultImpl;
import com.testyantra.basePackage.DTO.Employee;

@Component
public class DAOImplemtation implements DAOInterface {

	JdbcTemplate temp;
	
	
	public JdbcTemplate getTemp() {
		return temp;
	}

	public void setTemp(JdbcTemplate temp) {
		this.temp = temp;
	}


	public Employee authenticate(int id, String password) {
		RowMapper<Employee> rowMapper = new RowMapperImplementation();
		String query="SELECT * FROM sql_user.employee_db WHERE id =?";
		Employee employee=temp.queryForObject(query,rowMapper,id);
		return employee;

		
	}


	public List<Employee> getEmployee() {
		RowMapper<Employee> rowMapper = new RowMapperImplementation();
		String query = "SELECT * FROM sql_user.employee_db;";
		List<Employee> superheros = temp.query(query, rowMapper);
		return superheros;
	}

	
	public int addEmployee(Employee emp) {
	    
		String query = "INSERT INTO superhero_info VALUES (?,?,?)";
		int result = temp.update(query, emp.getId(),emp.getName(),emp.getPassword());
		return result;
	}

	
	}
	
	


